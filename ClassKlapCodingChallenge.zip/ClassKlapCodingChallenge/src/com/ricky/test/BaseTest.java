package com.ricky.test;

import org.testng.annotations.AfterMethod;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class BaseTest {

    protected ByteArrayOutputStream byteArrayOutputStream;
    protected PrintStream printStream;
    protected PrintStream oldPrintStream;

    @AfterMethod(alwaysRun = true)
    public void tearDown() throws IOException {
        System.out.flush();
        System.setOut(oldPrintStream);
    }
}

package com.ricky.test;

import com.ricky.Main;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class NegativeUnitTests extends BaseTest {

    @BeforeMethod(alwaysRun = true)
    public void setup() {
        Main.restart();
        byteArrayOutputStream = new ByteArrayOutputStream();
        printStream = new PrintStream(byteArrayOutputStream);
        oldPrintStream = System.out;
        System.setOut(printStream);
    }

    @Test
    public void testInitialize_InvalidInput() {
        Main.read = "create_parking_lot 0";
        Main.initialize();
        Assert.assertEquals("Prompt...Cannot create parking lot with 0 slots\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testInitialize_ParkingAlreadyExists() throws IOException {
        Main.read = "create_parking_lot 7";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 7 slots\n", byteArrayOutputStream.toString());
        Main.read = "create_parking_lot 14";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 7 slots\n" +
                "Prompt...Previous parking lot data cleared\r\n" +
                "Created a parking lot with 14 slots\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testPark_WithoutCreatingParkingLot() {
        Main.read = "park KA-01-HH-1234 White";
        Main.park();
        Assert.assertEquals("Prompt...Please create a parking lot first\r\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testLeave_SlotNotExists() {
        Main.read = "create_parking_lot 7";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 7 slots\n", byteArrayOutputStream.toString());
        Main.read = "leave 10";
        Main.leave();
        Assert.assertEquals("Created a parking lot with 7 slots\n" +
                "Prompt...Entered slot doesn't exist\r\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testLeave_SlotAlreadyEmpty() {
        Main.restart();
        Main.read = "create_parking_lot 7";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 7 slots\n", byteArrayOutputStream.toString());
        Main.read = "leave 6";
        Main.leave();
        Assert.assertEquals("Created a parking lot with 7 slots\n" +
                "Prompt...Slot is already empty\r\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testStatus_NoParking() {
        Main.read = "status";
        Main.status();
        Assert.assertEquals("Prompt...Please create a parking lot first\r\n", byteArrayOutputStream.toString());
    }

    @Test
    public void testStatus_EmptyParking() {
        Main.read = "create_parking_lot 7";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 7 slots\n", byteArrayOutputStream.toString());
        Main.read = "status";
        Main.status();
        Assert.assertEquals("Created a parking lot with 7 slots\n" +
                "Prompt...Parking Lot is Empty\r\n", byteArrayOutputStream.toString());
    }
}

package com.ricky.test;

import com.ricky.Main;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class MainTest extends BaseTest {

    public void refresh() throws IOException {
        tearDown();
        setup();
    }

    @BeforeClass(alwaysRun = true)
    public void setup() {
        byteArrayOutputStream = new ByteArrayOutputStream();
        printStream = new PrintStream(byteArrayOutputStream);
        oldPrintStream = System.out;
        System.setOut(printStream);
    }

    @Test
    public void testSampleWorkflow() throws Exception {

        Main.read = "create_parking_lot 6";
        Main.initialize();
        Assert.assertEquals("Created a parking lot with 6 slots\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-HH-1234 White";
        Main.park();
        Assert.assertEquals("Allocated slot number: 1\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-HH-9999 White";
        Main.park();
        Assert.assertEquals("Allocated slot number: 2\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-BB-0001 Black";
        Main.park();
        Assert.assertEquals("Allocated slot number: 3\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-HH-7777 Red";
        Main.park();
        Assert.assertEquals("Allocated slot number: 4\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-HH-2701 Blue";
        Main.park();
        Assert.assertEquals("Allocated slot number: 5\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-HH-3141 Black";
        Main.park();
        Assert.assertEquals("Allocated slot number: 6\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "leave 4";
        Main.leave();
        Assert.assertEquals("Slot number 4 is free\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "status";
        Main.status();
        String expected = "Slot No.\tRegistration No\t\tColor\r\n" +
                "1\t\t\tKA-01-HH-1234\t\tWhite\r\n" +
                "2\t\t\tKA-01-HH-9999\t\tWhite\r\n" +
                "3\t\t\tKA-01-BB-0001\t\tBlack\r\n" +
                "5\t\t\tKA-01-HH-2701\t\tBlue\r\n" +
                "6\t\t\tKA-01-HH-3141\t\tBlack\r\n";
        Assert.assertEquals(expected, byteArrayOutputStream.toString());

        refresh();

        Main.read = "park KA-01-P-333 White";
        Main.park();
        Assert.assertEquals("Allocated slot number: 4\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "park DL-12-AA-9999 White";
        Main.park();
        Assert.assertEquals("Sorry, parking lot is full\r\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "registration_numbers_for_cars_with_colour White";
        Main.registrationNumbersByColor();
        Assert.assertEquals("KA-01-HH-1234, KA-01-HH-9999, KA-01-P-333\r\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "slot_numbers_for_cars_with_colour White";
        Main.slotNumbersByColor();
        Assert.assertEquals("1, 2, 4\r\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "slot_number_for_registration_number KA-01-HH-3141";
        Main.slotNumberByRegNo();
        Assert.assertEquals("6\r\n", byteArrayOutputStream.toString());

        refresh();

        Main.read = "slot_number_for_registration_number MH-04-AY-1111";
        Main.slotNumberByRegNo();
        Assert.assertEquals("Not found\r\n", byteArrayOutputStream.toString());
    }


}

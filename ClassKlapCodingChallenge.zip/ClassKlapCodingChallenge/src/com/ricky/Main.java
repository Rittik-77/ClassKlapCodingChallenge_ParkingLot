package com.ricky;

import com.ricky.datamodel.Ticket;
import com.ricky.utils.BaseConstants;

import java.util.*;

public class Main {

    private static int numberParkingSlot = -1;
    private static SortedMap<Integer, Ticket> ticketSortedMap = new TreeMap<>();
    private static Scanner scanner = new Scanner(System.in);
    public static String read = "";

    public static void main(String[] args) {

        System.out.println(BaseConstants.PROMPT_INITIAL);
        boolean flag = true;

        do {
            read = scanner.nextLine();
            if (read.matches(BaseConstants.REGEX_CREATE_PARKING_LOT))
                initialize();
            else if (read.matches(BaseConstants.REGEX_PARK_CAR))
                park();
            else if (read.matches(BaseConstants.REGEX_LEAVE))
                leave();
            else if (read.matches(BaseConstants.STATUS))
                status();
            else if (read.matches(BaseConstants.REGEX_REG_NO_BY_COLOR))
                registrationNumbersByColor();
            else if(read.matches(BaseConstants.REGEX_SLOT_NO_BY_COLOR))
                slotNumbersByColor();
            else if(read.matches(BaseConstants.REGEX_SLOT_BY_REG))
                slotNumberByRegNo();
            else if (read.matches(BaseConstants.QUIT))
                flag = false;
            else
                System.out.println(BaseConstants.COMMAND_INVALID);

        } while (flag);

    }

    public static void restart() {
        numberParkingSlot = -1;
        ticketSortedMap = new TreeMap<>();
    }

    public static void initialize() {
        // Check if parking lot already exists
        if (!ticketSortedMap.isEmpty()) {
            ticketSortedMap.clear();
            numberParkingSlot = -1;
            System.out.println(BaseConstants.PROMPT_CLEARED);
        }

        // Read and validate number of slots in parking lot
        numberParkingSlot = Integer.parseInt(read.split(BaseConstants.REGEX_SPACE)[1]);
        if (numberParkingSlot < 1) {
            System.out.format(BaseConstants.PROMPT_INVALID_CREATE, numberParkingSlot);
            numberParkingSlot = -1;
            return;
        }

        // Initialize Parking Lot Map
        for (int i = 1; i <= numberParkingSlot; i++) {
            ticketSortedMap.put(i, new Ticket());
        }
        System.out.format(BaseConstants.RESPONSE_CREATE_PARKING_LOT, numberParkingSlot);
    }

    public static void park() {
        // Check if parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Parse ticket details
        String[] parsedInput = read.split(BaseConstants.REGEX_SPACE);

        // Find the nearest parking lot and allot slot
        Set entrySet = ticketSortedMap.entrySet();
        Iterator parkingIterator = entrySet.iterator();
        while (parkingIterator.hasNext()) {
            Map.Entry entry = (Map.Entry) parkingIterator.next();
            Ticket ticket = (Ticket) entry.getValue();
            if (ticket.getRegistrationNumber() == null && ticket.getColor() == null) {
                ((Ticket) entry.getValue()).setRegistrationNumber(parsedInput[1]);
                ((Ticket) entry.getValue()).setColor(parsedInput[2]);
                System.out.format(BaseConstants.RESPONSE_SLOT_ALLOCATED, entry.getKey());
                return;
            }
        }

        // If parking lot is full
        System.out.println(BaseConstants.RESPONSE_PARKING_FULL);
    }

    public static void leave() {
        // Check is parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Parse slot number
        int slotNumber = Integer.parseInt(read.split(BaseConstants.REGEX_SPACE)[1]);

        // Check if slot exists in parking
        if (slotNumber > numberParkingSlot) {
            System.out.println(BaseConstants.PROMPT_INVALID_SLOT);
            return;
        }

        // Check if slot is previously empty
        if (ticketSortedMap.get(slotNumber).getRegistrationNumber() == null) {
            System.out.println(BaseConstants.PROMPT_SLOT_EMPTY);
            return;
        }

        // Empty the slot
        ticketSortedMap.get(slotNumber).setRegistrationNumber(null);
        ticketSortedMap.get(slotNumber).setColor(null);
        System.out.format(BaseConstants.RESPONSE_SLOT_DEALLOCATE, slotNumber);
    }

    public static void status() {
        // Check is parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Check if parking is empty
        if(ticketSortedMap.get(1).getRegistrationNumber() == null) {
            System.out.println(BaseConstants.PROMPT_EMPTY_PARKING_LOT);
            return;
        }

        // Print to console
        System.out.println("Slot No.\tRegistration No\t\tColor");
        Set entrySet = ticketSortedMap.entrySet();
        Iterator parkingIterator = entrySet.iterator();
        while (parkingIterator.hasNext()) {
            Map.Entry entry = (Map.Entry) parkingIterator.next();
            Ticket ticket = (Ticket) entry.getValue();
            if (ticket.getRegistrationNumber() == null || ticket.getColor() == null)
                continue;
            System.out.println(entry.getKey().toString() + "\t\t\t" + ticket.getRegistrationNumber() + "\t\t" + ticket.getColor());
        }
    }

    public static void registrationNumbersByColor() {
        // Check is parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Initialize the list
        List<String> listRegNo = new ArrayList<>();

        // Get the color
        String color = read.split(BaseConstants.REGEX_SPACE)[1];

        // Prepare the list
        Iterator<Ticket> valueIterator = ticketSortedMap.values().iterator();
        while (valueIterator.hasNext()) {
            Ticket ticket = valueIterator.next();
            if(ticket.getColor().equals(color))
                listRegNo.add(ticket.getRegistrationNumber());
        }

        // Print the list
        if(listRegNo.isEmpty()) {
            System.out.println(BaseConstants.NOT_FOUND);
            return;
        }

        StringJoiner stringJoiner = new StringJoiner(", ");
        listRegNo.forEach(stringJoiner::add);
        System.out.println(stringJoiner);
    }

    public static void slotNumbersByColor() {
        // Check is parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Initialize the list
        List<String> listSlotNo = new ArrayList<>();

        // Get the color
        String color = read.split(BaseConstants.REGEX_SPACE)[1];

        // Prepare the list
        Set entrySet = ticketSortedMap.entrySet();
        Iterator parkingIterator = entrySet.iterator();
        while (parkingIterator.hasNext()) {
            Map.Entry entry = (Map.Entry) parkingIterator.next();
            Ticket ticket = (Ticket) entry.getValue();
            if(ticket.getColor().equals(color))
                listSlotNo.add(entry.getKey().toString());
        }

        // Print the list
        if(listSlotNo.isEmpty()) {
            System.out.println(BaseConstants.NOT_FOUND);
            return;
        }

        StringJoiner stringJoiner = new StringJoiner(", ");
        listSlotNo.forEach(stringJoiner::add);
        System.out.println(stringJoiner);
    }

    public static void slotNumberByRegNo() {
        // Check is parking lot exists
        if (numberParkingSlot == -1) {
            System.out.println(BaseConstants.PROMPT_CREATE_PARKING);
            return;
        }

        // Get the registration number
        String regNo = read.split(BaseConstants.REGEX_SPACE)[1];

        // Prepare the list
        Set entrySet = ticketSortedMap.entrySet();
        Iterator parkingIterator = entrySet.iterator();
        while (parkingIterator.hasNext()) {
            Map.Entry entry = (Map.Entry) parkingIterator.next();
            Ticket ticket = (Ticket) entry.getValue();
            if(ticket.getRegistrationNumber().equals(regNo)) {
                System.out.println(entry.getKey());
                return;
            }
        }

        System.out.println(BaseConstants.NOT_FOUND);
    }
}

package com.ricky.utils;

public class BaseConstants {

    public static final String QUIT = "quit";
    public static final String STATUS = "status";
    public static final String NOT_FOUND = "Not found";
    public static final String COMMAND_INVALID = "Command Invalid";

    public static final String PROMPT_INITIAL = "Prompt...\ncreate_parking_lot n - to create a parking lot of size n" +
            "\nquit - to exit the app" +
            "\npark reg_no color - to park a car" +
            "\nleave m - to leave slot m" +
            "\nstatus - to check current status of parking lot" +
            "\nregistration_numbers_for_cars_with_colour color - to fetch registration numbers of cars for specified color" +
            "\nslot_numbers_for_cars_with_colour color - to fetch slot numbers of cars for specified color" +
            "\nslot_number_for_registration_number reg_no - to fetch slot number of the car for specified reg_no";
    public static final String PROMPT_CLEARED = "Prompt...Previous parking lot data cleared";
    public static final String PROMPT_CREATE_PARKING = "Prompt...Please create a parking lot first";
    public static final String PROMPT_INVALID_CREATE = "Prompt...Cannot create parking lot with %d slots\n";
    public static final String PROMPT_INVALID_SLOT = "Prompt...Entered slot doesn't exist";
    public static final String PROMPT_SLOT_EMPTY = "Prompt...Slot is already empty";
    public static final String PROMPT_EMPTY_PARKING_LOT = "Prompt...Parking Lot is Empty";

    public static final String REGEX_CREATE_PARKING_LOT = "create_parking_lot\\s\\d+";
    public static final String REGEX_PARK_CAR = "park\\s[A-Z]{2}-[0-9]{2}-[A-Z]{1,2}-[0-9]{1,4}\\s[A-Z][a-z]+";
    public static final String REGEX_LEAVE = "leave\\s\\d+";
    public static final String REGEX_SPACE = "\\s";
    public static final String REGEX_REG_NO_BY_COLOR = "registration_numbers_for_cars_with_colour\\s[A-Z][a-z]+";
    public static final String REGEX_SLOT_NO_BY_COLOR = "slot_numbers_for_cars_with_colour\\s[A-Z][a-z]+";
    public static final String REGEX_SLOT_BY_REG = "slot_number_for_registration_number\\s[A-Z]{2}-[0-9]{2}-[A-Z]{1,2}-[0-9]{1,4}";

    public static final String RESPONSE_CREATE_PARKING_LOT = "Created a parking lot with %d slots\n";
    public static final String RESPONSE_PARKING_FULL = "Sorry, parking lot is full";
    public static final String RESPONSE_SLOT_ALLOCATED = "Allocated slot number: %d\n";
    public static final String RESPONSE_SLOT_DEALLOCATE = "Slot number %d is free\n";
}
